export type ComplaintStatus = 'pending' | 'in-progress' | 'resolved';
export type ComplaintCategory = 'roads' | 'sanitation' | 'water' | 'electricity' | 'parks' | 'safety' | 'other';

export interface Complaint {
  id: string;
  userId: string;
  userName: string;
  title: string;
  description: string;
  category: ComplaintCategory;
  location: string;
  status: ComplaintStatus;
  photo?: string;
  completedPhoto?: string;
  adminRemarks?: string;
  upvotes: number;
  createdAt: string;
  updatedAt: string;
  resolvedAt?: string;
}

const STORAGE_KEY = 'civicpulse_complaints';

const seedData: Complaint[] = [
  {
    id: '1',
    userId: 'user-1',
    userName: 'John Citizen',
    title: 'Large pothole on Main Street',
    description: 'There is a dangerous pothole near the intersection of Main St and Oak Ave. It has been causing damage to vehicles and poses a risk to cyclists.',
    category: 'roads',
    location: '123 Main Street, Downtown',
    status: 'pending',
    upvotes: 24,
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 3).toISOString(),
  },
  {
    id: '2',
    userId: 'user-1',
    userName: 'John Citizen',
    title: 'Broken streetlight in residential area',
    description: 'The streetlight at the corner of Elm Street has been out for two weeks. The area is very dark at night making it unsafe for pedestrians.',
    category: 'electricity',
    location: '456 Elm Street, Westside',
    status: 'in-progress',
    upvotes: 18,
    createdAt: new Date(Date.now() - 86400000 * 7).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: '3',
    userId: 'user-2',
    userName: 'Jane Doe',
    title: 'Overflowing garbage bins in park',
    description: 'The garbage bins in Central Park have been overflowing for days. This is attracting pests and creating an unpleasant smell for park visitors.',
    category: 'sanitation',
    location: 'Central Park, North Entrance',
    status: 'resolved',
    upvotes: 31,
    completedPhoto: 'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=400&h=300&fit=crop',
    adminRemarks: 'Bins have been emptied and additional bins added to the area.',
    createdAt: new Date(Date.now() - 86400000 * 14).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    resolvedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
  },
  {
    id: '4',
    userId: 'user-3',
    userName: 'Mike Smith',
    title: 'Water leak on Pine Avenue',
    description: 'There is a significant water leak from a broken pipe on Pine Avenue. Water is pooling on the street and sidewalk.',
    category: 'water',
    location: '789 Pine Avenue',
    status: 'in-progress',
    upvotes: 42,
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
  },
  {
    id: '5',
    userId: 'user-1',
    userName: 'John Citizen',
    title: 'Vandalism at bus stop shelter',
    description: 'The bus stop shelter on Market Street has been vandalized with graffiti and the glass panels are cracked.',
    category: 'safety',
    location: 'Market Street Bus Stop #12',
    status: 'pending',
    upvotes: 15,
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: '6',
    userId: 'user-4',
    userName: 'Sarah Johnson',
    title: 'Playground equipment needs repair',
    description: 'The swing set at Riverside Park has broken chains and the slide has rust damage. This is a safety hazard for children.',
    category: 'parks',
    location: 'Riverside Park, Playground Area',
    status: 'pending',
    upvotes: 28,
    createdAt: new Date(Date.now() - 86400000 * 4).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 4).toISOString(),
  },
];

export function getComplaints(): Complaint[] {
  if (typeof window === 'undefined') return [];
  
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(seedData));
    return seedData;
  }
  
  return JSON.parse(stored);
}

export function saveComplaints(complaints: Complaint[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(complaints));
}

export function addComplaint(complaint: Omit<Complaint, 'id' | 'upvotes' | 'createdAt' | 'updatedAt'>): Complaint {
  const complaints = getComplaints();
  const newComplaint: Complaint = {
    ...complaint,
    id: crypto.randomUUID(),
    upvotes: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  complaints.unshift(newComplaint);
  saveComplaints(complaints);
  return newComplaint;
}

export function updateComplaintStatus(id: string, status: ComplaintStatus): Complaint | null {
  const complaints = getComplaints();
  const index = complaints.findIndex(c => c.id === id);
  if (index === -1) return null;
  
  complaints[index] = {
    ...complaints[index],
    status,
    updatedAt: new Date().toISOString(),
  };
  saveComplaints(complaints);
  return complaints[index];
}

export function resolveComplaint(id: string, completedPhoto: string, remarks?: string): Complaint | null {
  const complaints = getComplaints();
  const index = complaints.findIndex(c => c.id === id);
  if (index === -1) return null;
  
  complaints[index] = {
    ...complaints[index],
    status: 'resolved',
    completedPhoto,
    adminRemarks: remarks,
    updatedAt: new Date().toISOString(),
    resolvedAt: new Date().toISOString(),
  };
  saveComplaints(complaints);
  return complaints[index];
}

export function upvoteComplaint(id: string): Complaint | null {
  const complaints = getComplaints();
  const index = complaints.findIndex(c => c.id === id);
  if (index === -1) return null;
  
  complaints[index] = {
    ...complaints[index],
    upvotes: complaints[index].upvotes + 1,
  };
  saveComplaints(complaints);
  return complaints[index];
}

export function getStats(complaints: Complaint[]) {
  return {
    total: complaints.length,
    pending: complaints.filter(c => c.status === 'pending').length,
    inProgress: complaints.filter(c => c.status === 'in-progress').length,
    resolved: complaints.filter(c => c.status === 'resolved').length,
  };
}

export function getUserComplaints(userId: string): Complaint[] {
  return getComplaints().filter(c => c.userId === userId);
}

export function getUserStats(userId: string) {
  const userComplaints = getUserComplaints(userId);
  return getStats(userComplaints);
}

export const categoryLabels: Record<ComplaintCategory, string> = {
  roads: 'Roads & Traffic',
  sanitation: 'Sanitation',
  water: 'Water Supply',
  electricity: 'Electricity',
  parks: 'Parks & Recreation',
  safety: 'Public Safety',
  other: 'Other',
};

export const statusLabels: Record<ComplaintStatus, string> = {
  pending: 'Pending',
  'in-progress': 'In Progress',
  resolved: 'Resolved',
};

export const categoryColors: Record<ComplaintCategory, string> = {
  roads: 'bg-orange-500',
  sanitation: 'bg-green-500',
  water: 'bg-blue-500',
  electricity: 'bg-yellow-500',
  parks: 'bg-emerald-500',
  safety: 'bg-red-500',
  other: 'bg-gray-500',
};

export const statusColors: Record<ComplaintStatus, string> = {
  pending: 'bg-amber-500',
  'in-progress': 'bg-primary',
  resolved: 'bg-accent',
};
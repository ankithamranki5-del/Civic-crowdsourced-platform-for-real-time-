export type UserRole = 'user' | 'admin';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

const AUTH_KEY = 'civicpulse_auth';

const DEMO_USERS: Record<string, { password: string; user: User }> = {
  'user@example.com': {
    password: 'user123',
    user: {
      id: 'user-1',
      email: 'user@example.com',
      name: 'John Citizen',
      role: 'user',
    },
  },
  'admin@example.com': {
    password: 'admin123',
    user: {
      id: 'admin-1',
      email: 'admin@example.com',
      name: 'Admin Officer',
      role: 'admin',
    },
  },
};

export function getAuthState(): AuthState {
  if (typeof window === 'undefined') {
    return { user: null, isAuthenticated: false };
  }
  
  const stored = localStorage.getItem(AUTH_KEY);
  if (!stored) {
    return { user: null, isAuthenticated: false };
  }
  
  try {
    const user = JSON.parse(stored) as User;
    return { user, isAuthenticated: true };
  } catch {
    return { user: null, isAuthenticated: false };
  }
}

export function login(email: string, password: string): { success: boolean; user?: User; error?: string } {
  const normalizedEmail = email.toLowerCase().trim();
  const demoUser = DEMO_USERS[normalizedEmail];
  
  if (!demoUser) {
    return { success: false, error: 'User not found' };
  }
  
  if (demoUser.password !== password) {
    return { success: false, error: 'Invalid password' };
  }
  
  localStorage.setItem(AUTH_KEY, JSON.stringify(demoUser.user));
  return { success: true, user: demoUser.user };
}

export function logout(): void {
  localStorage.removeItem(AUTH_KEY);
}

export function isAdmin(user: User | null): boolean {
  return user?.role === 'admin';
}
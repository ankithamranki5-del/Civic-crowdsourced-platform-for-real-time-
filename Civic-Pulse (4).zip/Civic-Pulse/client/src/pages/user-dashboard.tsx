import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'wouter';
import {
  AlertCircle,
  Clock,
  CheckCircle2,
  Plus,
  Search,
  ThumbsUp,
  MapPin,
  Calendar,
  X,
  Upload,
  Moon,
  Sun,
  TrendingUp,
  Zap,
  Droplets,
  TreePine,
  Shield,
  Car,
  Trash2,
  MoreHorizontal,
  LogOut,
  User,
  Image,
  MessageSquare,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/context/AuthContext';
import {
  type Complaint,
  type ComplaintStatus,
  type ComplaintCategory,
  getComplaints,
  addComplaint,
  upvoteComplaint,
  getUserStats,
  categoryLabels,
  statusLabels,
} from '@/lib/complaints';

const categoryIcons: Record<ComplaintCategory, React.ReactNode> = {
  roads: <Car className="w-4 h-4" />,
  sanitation: <Trash2 className="w-4 h-4" />,
  water: <Droplets className="w-4 h-4" />,
  electricity: <Zap className="w-4 h-4" />,
  parks: <TreePine className="w-4 h-4" />,
  safety: <Shield className="w-4 h-4" />,
  other: <MoreHorizontal className="w-4 h-4" />,
};

function ThemeToggle() {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const dark = document.documentElement.classList.contains('dark');
    setIsDark(dark);
  }, []);

  const toggle = () => {
    document.documentElement.classList.toggle('dark');
    setIsDark(!isDark);
  };

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={toggle}
      className="p-3 rounded-xl glass-card"
      data-testid="button-theme-toggle"
    >
      <AnimatePresence mode="wait">
        {isDark ? (
          <motion.div key="sun" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
            <Sun className="w-5 h-5 text-amber-400" />
          </motion.div>
        ) : (
          <motion.div key="moon" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
            <Moon className="w-5 h-5 text-slate-700" />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.button>
  );
}

interface StatCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  gradient: string;
  delay: number;
}

function StatCard({ title, value, icon, gradient, delay }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ y: -4, scale: 1.02 }}
      className="relative overflow-hidden rounded-2xl p-6 glass-card group cursor-default"
      data-testid={`stat-card-${title.toLowerCase().replace(/\s/g, '-')}`}
    >
      <div className={`absolute inset-0 opacity-10 ${gradient}`} />
      <div className="relative z-10">
        <div className={`inline-flex p-3 rounded-xl ${gradient} text-white mb-4`}>{icon}</div>
        <motion.p
          className="text-4xl font-bold font-display mb-1"
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: delay + 0.2, type: 'spring', stiffness: 200 }}
        >
          {value}
        </motion.p>
        <p className="text-muted-foreground text-sm font-medium">{title}</p>
      </div>
      <motion.div
        className={`absolute -bottom-10 -right-10 w-32 h-32 rounded-full ${gradient} opacity-20 blur-2xl`}
        animate={{ scale: [1, 1.2, 1] }}
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
      />
    </motion.div>
  );
}

interface ComplaintDetailModalProps {
  complaint: Complaint;
  isOpen: boolean;
  onClose: () => void;
}

function ComplaintDetailModal({ complaint, isOpen, onClose }: ComplaintDetailModalProps) {
  const statusGradient = {
    pending: 'from-amber-500 to-orange-500',
    'in-progress': 'from-primary to-purple-500',
    resolved: 'from-accent to-emerald-500',
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card border-0 max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display pr-8">{complaint.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          <div className="flex items-center gap-3">
            <Badge className={`bg-gradient-to-r ${statusGradient[complaint.status]} text-white border-0`}>
              {statusLabels[complaint.status]}
            </Badge>
            <Badge variant="outline">{categoryLabels[complaint.category]}</Badge>
          </div>

          <div className="space-y-2">
            <p className="text-muted-foreground">{complaint.description}</p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {complaint.location}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {new Date(complaint.createdAt).toLocaleDateString()}
              </span>
            </div>
          </div>

          {complaint.photo && (
            <div>
              <Label className="flex items-center gap-2 mb-2">
                <Image className="w-4 h-4" />
                Your Submitted Photo
              </Label>
              <img src={complaint.photo} alt="Issue" className="w-full h-64 object-cover rounded-xl" />
            </div>
          )}

          {complaint.status === 'resolved' && complaint.completedPhoto && (
            <div className="p-4 rounded-xl bg-accent/10 border border-accent/20">
              <Label className="flex items-center gap-2 mb-2 text-accent">
                <CheckCircle2 className="w-4 h-4" />
                Work Completed Photo
              </Label>
              <img src={complaint.completedPhoto} alt="Completed work" className="w-full h-64 object-cover rounded-xl mb-3" />
              {complaint.adminRemarks && (
                <div className="flex items-start gap-2 text-sm">
                  <MessageSquare className="w-4 h-4 mt-0.5 text-muted-foreground" />
                  <p className="text-muted-foreground">{complaint.adminRemarks}</p>
                </div>
              )}
              {complaint.resolvedAt && (
                <p className="text-xs text-muted-foreground mt-2">
                  Resolved on {new Date(complaint.resolvedAt).toLocaleDateString()}
                </p>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

interface ComplaintCardProps {
  complaint: Complaint;
  onUpvote: (id: string) => void;
  onViewDetails: (complaint: Complaint) => void;
}

function ComplaintCard({ complaint, onUpvote, onViewDetails }: ComplaintCardProps) {
  const statusGradient = {
    pending: 'from-amber-500 to-orange-500',
    'in-progress': 'from-primary to-purple-500',
    resolved: 'from-accent to-emerald-500',
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: -10 }}
      whileHover={{ y: -2 }}
      className="glass-card rounded-2xl p-5 group cursor-pointer"
      onClick={() => onViewDetails(complaint)}
      data-testid={`complaint-card-${complaint.id}`}
    >
      <div className="flex items-start gap-4">
        <div className={`p-3 rounded-xl bg-gradient-to-br ${statusGradient[complaint.status]} text-white shrink-0`}>
          {categoryIcons[complaint.category]}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-3 mb-2">
            <h3 className="font-semibold text-lg leading-tight line-clamp-2">{complaint.title}</h3>
            <Badge variant="secondary" className={`shrink-0 bg-gradient-to-r ${statusGradient[complaint.status]} text-white border-0`}>
              {statusLabels[complaint.status]}
            </Badge>
          </div>

          <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{complaint.description}</p>

          <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground mb-4">
            <span className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              {complaint.location}
            </span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {new Date(complaint.createdAt).toLocaleDateString()}
            </span>
          </div>

          {complaint.status === 'resolved' && complaint.completedPhoto && (
            <div className="flex items-center gap-2 text-xs text-accent mb-3">
              <CheckCircle2 className="w-4 h-4" />
              <span>Work completed - Click to view</span>
            </div>
          )}

          <div className="flex items-center gap-2">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={(e) => {
                e.stopPropagation();
                onUpvote(complaint.id);
              }}
              className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/10 hover:bg-primary/20 text-primary transition-colors"
              data-testid={`button-upvote-${complaint.id}`}
            >
              <ThumbsUp className="w-4 h-4" />
              <span className="font-medium">{complaint.upvotes}</span>
            </motion.button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function NewComplaintDialog({ userId, userName, onSubmit }: { userId: string; userName: string; onSubmit: (data: Omit<Complaint, 'id' | 'upvotes' | 'createdAt' | 'updatedAt'>) => void }) {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<ComplaintCategory>('other');
  const [location, setLocation] = useState('');
  const [photo, setPhoto] = useState<string | undefined>();

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (!title.trim() || !description.trim() || !location.trim()) return;

    onSubmit({
      userId,
      userName,
      title: title.trim(),
      description: description.trim(),
      category,
      location: location.trim(),
      status: 'pending',
      photo,
    });

    setTitle('');
    setDescription('');
    setCategory('other');
    setLocation('');
    setPhoto(undefined);
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-primary to-purple-500 text-white font-semibold shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-shadow"
          data-testid="button-new-complaint"
        >
          <Plus className="w-5 h-5" />
          Report Issue
        </motion.button>
      </DialogTrigger>
      <DialogContent className="glass-card border-0 max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display">Report New Issue</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-4">
          <div>
            <Label htmlFor="title">Title</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Brief description of the issue" className="mt-1.5" data-testid="input-title" />
          </div>

          <div>
            <Label htmlFor="category">Category</Label>
            <Select value={category} onValueChange={(v) => setCategory(v as ComplaintCategory)}>
              <SelectTrigger className="mt-1.5" data-testid="select-category">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(categoryLabels).map(([key, label]) => (
                  <SelectItem key={key} value={key}>
                    <span className="flex items-center gap-2">
                      {categoryIcons[key as ComplaintCategory]}
                      {label}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="location">Location</Label>
            <Input id="location" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Address or landmark" className="mt-1.5" data-testid="input-location" />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Detailed description of the issue..." rows={4} className="mt-1.5" data-testid="input-description" />
          </div>

          <div>
            <Label>Photo (Optional)</Label>
            <div className="mt-1.5">
              {photo ? (
                <div className="relative rounded-xl overflow-hidden">
                  <img src={photo} alt="Preview" className="w-full h-40 object-cover" />
                  <button onClick={() => setPhoto(undefined)} className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/50 text-white hover:bg-black/70" data-testid="button-remove-photo">
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center w-full h-32 rounded-xl border-2 border-dashed border-muted-foreground/25 hover:border-primary/50 cursor-pointer transition-colors">
                  <Upload className="w-8 h-8 text-muted-foreground mb-2" />
                  <span className="text-sm text-muted-foreground">Click to upload</span>
                  <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" data-testid="input-photo" />
                </label>
              )}
            </div>
          </div>

          <Button onClick={handleSubmit} disabled={!title.trim() || !description.trim() || !location.trim()} className="w-full bg-gradient-to-r from-primary to-purple-500 hover:opacity-90" data-testid="button-submit-complaint">
            Submit Report
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function UserDashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<ComplaintStatus | 'all'>('all');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    setComplaints(getComplaints().filter((c) => c.userId === user.id));
  }, [user, navigate]);

  const stats = useMemo(() => (user ? getUserStats(user.id) : { total: 0, pending: 0, inProgress: 0, resolved: 0 }), [user, complaints]);

  const filteredComplaints = useMemo(() => {
    return complaints.filter((c) => {
      const matchesSearch = c.title.toLowerCase().includes(searchQuery.toLowerCase()) || c.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [complaints, searchQuery, statusFilter]);

  const handleAddComplaint = (data: Omit<Complaint, 'id' | 'upvotes' | 'createdAt' | 'updatedAt'>) => {
    const newComplaint = addComplaint(data);
    setComplaints((prev) => [newComplaint, ...prev]);
    toast({ title: 'Issue Reported', description: 'Your complaint has been submitted successfully.' });
  };

  const handleUpvote = (id: string) => {
    const updated = upvoteComplaint(id);
    if (updated) {
      setComplaints((prev) => prev.map((c) => (c.id === id ? updated : c)));
      toast({ title: 'Upvoted!', description: 'Your support has been recorded.' });
    }
  };

  const handleLogout = () => {
    logout();
    toast({ title: 'Logged out', description: 'See you next time!' });
    navigate('/');
  };

  if (!user) return null;

  return (
    <div className="min-h-screen gradient-bg noise-overlay relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-primary/20 blur-3xl" animate={{ scale: [1, 1.2, 1], rotate: [0, 90, 0] }} transition={{ duration: 20, repeat: Infinity, ease: 'linear' }} />
        <motion.div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-accent/20 blur-3xl" animate={{ scale: [1.2, 1, 1.2], rotate: [0, -90, 0] }} transition={{ duration: 25, repeat: Infinity, ease: 'linear' }} />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8 max-w-7xl">
        <motion.header initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold font-display gradient-text mb-2">My Dashboard</h1>
            <p className="text-muted-foreground flex items-center gap-2">
              <User className="w-4 h-4" />
              Welcome, {user.name}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <NewComplaintDialog userId={user.id} userName={user.name} onSubmit={handleAddComplaint} />
            <ThemeToggle />
            <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={handleLogout} className="p-3 rounded-xl glass-card text-destructive" data-testid="button-logout">
              <LogOut className="w-5 h-5" />
            </motion.button>
          </div>
        </motion.header>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          <StatCard title="My Issues" value={stats.total} icon={<TrendingUp className="w-6 h-6" />} gradient="stat-gradient-total" delay={0} />
          <StatCard title="Pending" value={stats.pending} icon={<AlertCircle className="w-6 h-6" />} gradient="stat-gradient-pending" delay={0.1} />
          <StatCard title="In Progress" value={stats.inProgress} icon={<Clock className="w-6 h-6" />} gradient="stat-gradient-progress" delay={0.2} />
          <StatCard title="Resolved" value={stats.resolved} icon={<CheckCircle2 className="w-6 h-6" />} gradient="stat-gradient-resolved" delay={0.3} />
        </div>

        <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
            <h2 className="text-2xl font-bold font-display">My Complaints</h2>

            <div className="flex flex-wrap items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input placeholder="Search..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10 w-48" data-testid="input-search" />
              </div>

              <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as ComplaintStatus | 'all')}>
                <SelectTrigger className="w-36" data-testid="select-status-filter">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <AnimatePresence mode="popLayout">
            {filteredComplaints.length === 0 ? (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card rounded-2xl p-12 text-center">
                <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No complaints yet</h3>
                <p className="text-muted-foreground">Report your first issue to get started!</p>
              </motion.div>
            ) : (
              <div className="grid gap-4">
                {filteredComplaints.map((complaint) => (
                  <ComplaintCard key={complaint.id} complaint={complaint} onUpvote={handleUpvote} onViewDetails={setSelectedComplaint} />
                ))}
              </div>
            )}
          </AnimatePresence>
        </motion.section>

        <motion.footer initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="mt-16 text-center text-muted-foreground text-sm">
          <p>CivicPulse — Building better communities together</p>
        </motion.footer>
      </div>

      {selectedComplaint && <ComplaintDetailModal complaint={selectedComplaint} isOpen={!!selectedComplaint} onClose={() => setSelectedComplaint(null)} />}
    </div>
  );
}
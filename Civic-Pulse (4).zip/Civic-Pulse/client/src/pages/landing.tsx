import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'wouter';
import {
  FileText,
  Search,
  CheckCircle,
  Users,
  BarChart3,
  Shield,
  Clock,
  Zap,
  ArrowRight,
  X,
  Mail,
  Lock,
  User,
  UserCog,
  AlertCircle,
  TrendingUp,
  Sun,
  Moon,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { getStats, getComplaints } from '@/lib/complaints';
import { useEffect, useMemo, useState as useStateEffect } from 'react';

function ThemeToggle() {
  const [isDark, setIsDark] = useState(false);
  
  useEffect(() => {
    const dark = document.documentElement.classList.contains('dark');
    setIsDark(dark);
  }, []);
  
  const toggle = () => {
    document.documentElement.classList.toggle('dark');
    setIsDark(!isDark);
  };
  
  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={toggle}
      className="p-3 rounded-xl glass-card"
      data-testid="button-theme-toggle"
    >
      <AnimatePresence mode="wait">
        {isDark ? (
          <motion.div
            key="sun"
            initial={{ rotate: -90, opacity: 0 }}
            animate={{ rotate: 0, opacity: 1 }}
            exit={{ rotate: 90, opacity: 0 }}
          >
            <Sun className="w-5 h-5 text-amber-400" />
          </motion.div>
        ) : (
          <motion.div
            key="moon"
            initial={{ rotate: 90, opacity: 0 }}
            animate={{ rotate: 0, opacity: 1 }}
            exit={{ rotate: -90, opacity: 0 }}
          >
            <Moon className="w-5 h-5 text-slate-700" />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.button>
  );
}

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  role: 'user' | 'admin';
}

function LoginModal({ isOpen, onClose, role }: LoginModalProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { login } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);

    setTimeout(() => {
      const result = login(email, password);
      setIsSubmitting(false);

      if (result.success) {
        toast({
          title: 'Welcome back!',
          description: `Logged in successfully as ${role}.`,
        });
        onClose();
        navigate(role === 'admin' ? '/admin' : '/dashboard');
      } else {
        setError(result.error || 'Login failed');
      }
    }, 500);
  };

  const demoCredentials = role === 'admin' 
    ? { email: 'admin@example.com', password: 'admin123' }
    : { email: 'user@example.com', password: 'user123' };

  const fillDemo = () => {
    setEmail(demoCredentials.email);
    setPassword(demoCredentials.password);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card border-0 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display flex items-center gap-3">
            {role === 'admin' ? (
              <>
                <div className="p-2 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 text-white">
                  <UserCog className="w-5 h-5" />
                </div>
                Admin Login
              </>
            ) : (
              <>
                <div className="p-2 rounded-lg bg-gradient-to-br from-primary to-blue-500 text-white">
                  <User className="w-5 h-5" />
                </div>
                User Login
              </>
            )}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm"
            >
              <AlertCircle className="w-4 h-4" />
              {error}
            </motion.div>
          )}

          <div>
            <Label htmlFor="email">Email</Label>
            <div className="relative mt-1.5">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email"
                className="pl-10"
                required
                data-testid="input-email"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="password">Password</Label>
            <div className="relative mt-1.5">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="pl-10"
                required
                data-testid="input-password"
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-primary to-purple-500 hover:opacity-90"
            data-testid="button-submit-login"
          >
            {isSubmitting ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
              />
            ) : (
              <>
                Sign In
                <ArrowRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">Demo</span>
            </div>
          </div>

          <button
            type="button"
            onClick={fillDemo}
            className="w-full p-3 rounded-lg border border-dashed border-muted-foreground/30 hover:border-primary/50 hover:bg-primary/5 transition-colors text-sm text-muted-foreground"
            data-testid="button-fill-demo"
          >
            Use demo credentials: <span className="font-mono text-foreground">{demoCredentials.email}</span>
          </button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

const steps = [
  {
    icon: <FileText className="w-8 h-8" />,
    title: 'Report',
    description: 'Submit civic issues with photos, location, and detailed descriptions.',
    gradient: 'from-orange-500 to-red-500',
  },
  {
    icon: <Search className="w-8 h-8" />,
    title: 'Track',
    description: 'Monitor your complaints in real-time as they progress through the system.',
    gradient: 'from-primary to-purple-500',
  },
  {
    icon: <CheckCircle className="w-8 h-8" />,
    title: 'Resolve',
    description: 'Get notified when issues are resolved with proof of completed work.',
    gradient: 'from-accent to-emerald-500',
  },
];

const benefits = [
  {
    icon: <Clock className="w-6 h-6" />,
    title: 'Fast Response',
    description: 'Issues are addressed quickly with priority tracking.',
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: 'Transparent Process',
    description: 'Track every step from report to resolution.',
  },
  {
    icon: <Users className="w-6 h-6" />,
    title: 'Community Driven',
    description: 'Upvote issues to prioritize what matters most.',
  },
  {
    icon: <Zap className="w-6 h-6" />,
    title: 'Instant Updates',
    description: 'Real-time notifications on your complaints.',
  },
];

export default function Landing() {
  const [loginModal, setLoginModal] = useState<{ isOpen: boolean; role: 'user' | 'admin' }>({
    isOpen: false,
    role: 'user',
  });

  const stats = useMemo(() => getStats(getComplaints()), []);

  const openLogin = (role: 'user' | 'admin') => {
    setLoginModal({ isOpen: true, role });
  };

  return (
    <div className="min-h-screen gradient-bg noise-overlay relative overflow-hidden">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute -top-40 -right-40 w-[500px] h-[500px] rounded-full bg-primary/20 blur-3xl"
          animate={{ scale: [1, 1.3, 1], x: [0, 50, 0], y: [0, 30, 0] }}
          transition={{ duration: 20, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute -bottom-40 -left-40 w-[500px] h-[500px] rounded-full bg-accent/20 blur-3xl"
          animate={{ scale: [1.2, 1, 1.2], x: [0, -30, 0], y: [0, -50, 0] }}
          transition={{ duration: 25, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-purple-500/10 blur-3xl"
          animate={{ scale: [1, 1.2, 1], rotate: [0, 180, 360] }}
          transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
        />
      </div>

      <div className="relative z-10">
        <motion.header
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="container mx-auto px-4 py-6 flex items-center justify-between max-w-7xl"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-gradient-to-br from-primary to-purple-500 text-white">
              <BarChart3 className="w-6 h-6" />
            </div>
            <span className="text-2xl font-bold font-display gradient-text">CivicPulse</span>
          </div>
          <ThemeToggle />
        </motion.header>

        <section className="container mx-auto px-4 pt-16 pb-24 max-w-7xl">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6">
                <TrendingUp className="w-4 h-4" />
                Trusted by 10,000+ citizens
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-5xl md:text-7xl font-bold font-display mb-6 leading-tight"
            >
              Report. Track.{' '}
              <span className="gradient-text">Resolve.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto"
            >
              Empower your community by reporting civic issues instantly. Track progress in real-time and see verified results when work is completed.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4"
            >
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => openLogin('user')}
                className="flex items-center gap-3 px-8 py-4 rounded-xl bg-gradient-to-r from-primary to-purple-500 text-white font-semibold shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all w-full sm:w-auto"
                data-testid="button-user-login"
              >
                <User className="w-5 h-5" />
                User Login
                <ArrowRight className="w-5 h-5" />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => openLogin('admin')}
                className="flex items-center gap-3 px-8 py-4 rounded-xl glass-card font-semibold hover:bg-white/90 dark:hover:bg-white/20 transition-all w-full sm:w-auto"
                data-testid="button-admin-login"
              >
                <UserCog className="w-5 h-5" />
                Admin Login
              </motion.button>
            </motion.div>
          </div>
        </section>

        <section className="container mx-auto px-4 pb-24 max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4"
          >
            {[
              { label: 'Total Issues', value: stats.total, gradient: 'stat-gradient-total' },
              { label: 'Pending', value: stats.pending, gradient: 'stat-gradient-pending' },
              { label: 'In Progress', value: stats.inProgress, gradient: 'stat-gradient-progress' },
              { label: 'Resolved', value: stats.resolved, gradient: 'stat-gradient-resolved' },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card rounded-2xl p-6 text-center"
              >
                <div className={`inline-flex w-12 h-12 rounded-xl ${stat.gradient} items-center justify-center text-white text-xl font-bold mb-3`}>
                  {stat.value}
                </div>
                <p className="text-sm text-muted-foreground font-medium">{stat.label}</p>
              </motion.div>
            ))}
          </motion.div>
        </section>

        <section className="container mx-auto px-4 pb-24 max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold font-display mb-4">How It Works</h2>
            <p className="text-muted-foreground text-lg">Three simple steps to a better community</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step, i) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                whileHover={{ y: -8 }}
                className="glass-card rounded-3xl p-8 relative overflow-hidden group"
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${step.gradient} opacity-0 group-hover:opacity-5 transition-opacity`} />
                <div className={`inline-flex p-4 rounded-2xl bg-gradient-to-br ${step.gradient} text-white mb-6`}>
                  {step.icon}
                </div>
                <div className="absolute top-6 right-6 text-7xl font-bold text-muted-foreground/10 font-display">
                  {i + 1}
                </div>
                <h3 className="text-2xl font-bold font-display mb-3">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="container mx-auto px-4 pb-24 max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold font-display mb-4">Why CivicPulse?</h2>
            <p className="text-muted-foreground text-lg">Built for communities that care</p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, i) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className="glass-card rounded-2xl p-6"
              >
                <div className="inline-flex p-3 rounded-xl bg-primary/10 text-primary mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-lg font-semibold mb-2">{benefit.title}</h3>
                <p className="text-sm text-muted-foreground">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </section>

        <section className="container mx-auto px-4 pb-24 max-w-7xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass-card rounded-3xl p-12 text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10" />
            <div className="relative z-10">
              <h2 className="text-4xl font-bold font-display mb-4">Ready to Make a Difference?</h2>
              <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
                Join thousands of citizens who are actively improving their neighborhoods.
              </p>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => openLogin('user')}
                className="inline-flex items-center gap-3 px-8 py-4 rounded-xl bg-gradient-to-r from-primary to-purple-500 text-white font-semibold shadow-lg shadow-primary/25"
                data-testid="button-get-started"
              >
                Get Started
                <ArrowRight className="w-5 h-5" />
              </motion.button>
            </div>
          </motion.div>
        </section>

        <footer className="container mx-auto px-4 pb-8 max-w-7xl text-center text-muted-foreground text-sm">
          <p>CivicPulse — Building better communities together</p>
        </footer>
      </div>

      <LoginModal
        isOpen={loginModal.isOpen}
        onClose={() => setLoginModal({ ...loginModal, isOpen: false })}
        role={loginModal.role}
      />
    </div>
  );
}
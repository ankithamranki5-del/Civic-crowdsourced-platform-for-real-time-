import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'wouter';
import {
  AlertCircle,
  Clock,
  CheckCircle2,
  BarChart3,
  Search,
  Filter,
  ThumbsUp,
  MapPin,
  Calendar,
  Moon,
  Sun,
  TrendingUp,
  Zap,
  Droplets,
  TreePine,
  Shield,
  Car,
  Trash2,
  MoreHorizontal,
  LogOut,
  UserCog,
  Image,
  Upload,
  X,
  ChevronRight,
  User,
  MessageSquare,
  Eye,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/context/AuthContext';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import {
  type Complaint,
  type ComplaintStatus,
  type ComplaintCategory,
  getComplaints,
  saveComplaints,
  updateComplaintStatus,
  resolveComplaint,
  getStats,
  categoryLabels,
  statusLabels,
} from '@/lib/complaints';

const categoryIcons: Record<ComplaintCategory, React.ReactNode> = {
  roads: <Car className="w-4 h-4" />,
  sanitation: <Trash2 className="w-4 h-4" />,
  water: <Droplets className="w-4 h-4" />,
  electricity: <Zap className="w-4 h-4" />,
  parks: <TreePine className="w-4 h-4" />,
  safety: <Shield className="w-4 h-4" />,
  other: <MoreHorizontal className="w-4 h-4" />,
};

const CHART_COLORS = ['#f59e0b', '#6366f1', '#14b8a6'];

function ThemeToggle() {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const dark = document.documentElement.classList.contains('dark');
    setIsDark(dark);
  }, []);

  const toggle = () => {
    document.documentElement.classList.toggle('dark');
    setIsDark(!isDark);
  };

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={toggle}
      className="p-3 rounded-xl glass-card"
      data-testid="button-theme-toggle"
    >
      <AnimatePresence mode="wait">
        {isDark ? (
          <motion.div key="sun" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }}>
            <Sun className="w-5 h-5 text-amber-400" />
          </motion.div>
        ) : (
          <motion.div key="moon" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }}>
            <Moon className="w-5 h-5 text-slate-700" />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.button>
  );
}

interface StatCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  gradient: string;
  delay: number;
}

function StatCard({ title, value, icon, gradient, delay }: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ y: -4, scale: 1.02 }}
      className="relative overflow-hidden rounded-2xl p-6 glass-card group cursor-default"
    >
      <div className={`absolute inset-0 opacity-10 ${gradient}`} />
      <div className="relative z-10">
        <div className={`inline-flex p-3 rounded-xl ${gradient} text-white mb-4`}>{icon}</div>
        <motion.p
          className="text-4xl font-bold font-display mb-1"
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: delay + 0.2, type: 'spring', stiffness: 200 }}
        >
          {value}
        </motion.p>
        <p className="text-muted-foreground text-sm font-medium">{title}</p>
      </div>
    </motion.div>
  );
}

interface ComplaintDetailModalProps {
  complaint: Complaint;
  isOpen: boolean;
  onClose: () => void;
  onStatusUpdate: (id: string, status: ComplaintStatus) => void;
  onResolve: (id: string, photo: string, remarks?: string) => void;
}

function ComplaintDetailModal({ complaint, isOpen, onClose, onStatusUpdate, onResolve }: ComplaintDetailModalProps) {
  const [completedPhoto, setCompletedPhoto] = useState<string>('');
  const [remarks, setRemarks] = useState('');

  const statusGradient = {
    pending: 'from-amber-500 to-orange-500',
    'in-progress': 'from-primary to-purple-500',
    resolved: 'from-accent to-emerald-500',
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCompletedPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleResolve = () => {
    if (!completedPhoto) return;
    onResolve(complaint.id, completedPhoto, remarks.trim() || undefined);
    setCompletedPhoto('');
    setRemarks('');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card border-0 max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display pr-8">{complaint.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          <div className="flex items-center gap-3 flex-wrap">
            <Badge className={`bg-gradient-to-r ${statusGradient[complaint.status]} text-white border-0`}>
              {statusLabels[complaint.status]}
            </Badge>
            <Badge variant="outline">{categoryLabels[complaint.category]}</Badge>
            <Badge variant="secondary" className="flex items-center gap-1">
              <User className="w-3 h-3" />
              {complaint.userName}
            </Badge>
          </div>

          <div className="space-y-2">
            <p className="text-muted-foreground">{complaint.description}</p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
              <span className="flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                {complaint.location}
              </span>
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {new Date(complaint.createdAt).toLocaleDateString()}
              </span>
              <span className="flex items-center gap-1">
                <ThumbsUp className="w-4 h-4" />
                {complaint.upvotes} upvotes
              </span>
            </div>
          </div>

          {complaint.photo && (
            <div>
              <Label className="flex items-center gap-2 mb-2">
                <Image className="w-4 h-4" />
                User Submitted Photo
              </Label>
              <img src={complaint.photo} alt="Issue" className="w-full h-64 object-cover rounded-xl" />
            </div>
          )}

          {complaint.status !== 'resolved' && (
            <div className="p-4 rounded-xl bg-muted/50 space-y-4">
              <h4 className="font-semibold flex items-center gap-2">
                <ChevronRight className="w-4 h-4" />
                Update Status
              </h4>

              {complaint.status === 'pending' && (
                <Button
                  onClick={() => {
                    onStatusUpdate(complaint.id, 'in-progress');
                    onClose();
                  }}
                  className="bg-gradient-to-r from-primary to-purple-500"
                  data-testid="button-mark-in-progress"
                >
                  Mark as In Progress
                </Button>
              )}

              {complaint.status === 'in-progress' && (
                <div className="space-y-4">
                  <div>
                    <Label className="flex items-center gap-2 mb-2">
                      <Upload className="w-4 h-4" />
                      Work Completed Photo (Required)
                    </Label>
                    {completedPhoto ? (
                      <div className="relative rounded-xl overflow-hidden">
                        <img src={completedPhoto} alt="Preview" className="w-full h-40 object-cover" />
                        <button
                          onClick={() => setCompletedPhoto('')}
                          className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/50 text-white hover:bg-black/70"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <label className="flex flex-col items-center justify-center w-full h-32 rounded-xl border-2 border-dashed border-muted-foreground/25 hover:border-accent/50 cursor-pointer transition-colors">
                        <Upload className="w-8 h-8 text-muted-foreground mb-2" />
                        <span className="text-sm text-muted-foreground">Upload completed work photo</span>
                        <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" data-testid="input-completed-photo" />
                      </label>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="remarks" className="flex items-center gap-2 mb-2">
                      <MessageSquare className="w-4 h-4" />
                      Remarks (Optional)
                    </Label>
                    <Textarea
                      id="remarks"
                      value={remarks}
                      onChange={(e) => setRemarks(e.target.value)}
                      placeholder="Add any notes about the completed work..."
                      rows={3}
                      data-testid="input-remarks"
                    />
                  </div>

                  <Button
                    onClick={handleResolve}
                    disabled={!completedPhoto}
                    className="w-full bg-gradient-to-r from-accent to-emerald-500"
                    data-testid="button-mark-resolved"
                  >
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Mark as Resolved
                  </Button>
                </div>
              )}
            </div>
          )}

          {complaint.status === 'resolved' && complaint.completedPhoto && (
            <div className="p-4 rounded-xl bg-accent/10 border border-accent/20">
              <Label className="flex items-center gap-2 mb-2 text-accent">
                <CheckCircle2 className="w-4 h-4" />
                Work Completed Photo
              </Label>
              <img src={complaint.completedPhoto} alt="Completed work" className="w-full h-64 object-cover rounded-xl mb-3" />
              {complaint.adminRemarks && (
                <div className="flex items-start gap-2 text-sm">
                  <MessageSquare className="w-4 h-4 mt-0.5 text-muted-foreground" />
                  <p className="text-muted-foreground">{complaint.adminRemarks}</p>
                </div>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

interface ComplaintRowProps {
  complaint: Complaint;
  onClick: () => void;
}

function ComplaintRow({ complaint, onClick }: ComplaintRowProps) {
  const statusGradient = {
    pending: 'from-amber-500 to-orange-500',
    'in-progress': 'from-primary to-purple-500',
    resolved: 'from-accent to-emerald-500',
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ x: 4 }}
      onClick={onClick}
      className="glass-card rounded-xl p-4 cursor-pointer group"
      data-testid={`complaint-row-${complaint.id}`}
    >
      <div className="flex items-center gap-4">
        <div className={`p-2 rounded-lg bg-gradient-to-br ${statusGradient[complaint.status]} text-white shrink-0`}>
          {categoryIcons[complaint.category]}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-medium truncate">{complaint.title}</h3>
            <Badge variant="secondary" className={`shrink-0 text-xs bg-gradient-to-r ${statusGradient[complaint.status]} text-white border-0`}>
              {statusLabels[complaint.status]}
            </Badge>
          </div>
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <User className="w-3 h-3" />
              {complaint.userName}
            </span>
            <span className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              {complaint.location}
            </span>
            <span className="flex items-center gap-1">
              <ThumbsUp className="w-3 h-3" />
              {complaint.upvotes}
            </span>
          </div>
        </div>

        <Eye className="w-5 h-5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
    </motion.div>
  );
}

export default function AdminDashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<ComplaintStatus | 'all'>('all');
  const [categoryFilter, setCategoryFilter] = useState<ComplaintCategory | 'all'>('all');
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/');
      return;
    }
    setComplaints(getComplaints());
  }, [user, navigate]);

  const stats = useMemo(() => getStats(complaints), [complaints]);

  const filteredComplaints = useMemo(() => {
    return complaints.filter((c) => {
      const matchesSearch =
        c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.userName.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
      const matchesCategory = categoryFilter === 'all' || c.category === categoryFilter;
      return matchesSearch && matchesStatus && matchesCategory;
    });
  }, [complaints, searchQuery, statusFilter, categoryFilter]);

  const pieData = useMemo(
    () => [
      { name: 'Pending', value: stats.pending },
      { name: 'In Progress', value: stats.inProgress },
      { name: 'Resolved', value: stats.resolved },
    ],
    [stats]
  );

  const barData = useMemo(() => {
    const categoryCounts: Record<string, number> = {};
    complaints.forEach((c) => {
      categoryCounts[c.category] = (categoryCounts[c.category] || 0) + 1;
    });
    return Object.entries(categoryCounts).map(([category, count]) => ({
      category: categoryLabels[category as ComplaintCategory],
      count,
    }));
  }, [complaints]);

  const handleStatusUpdate = (id: string, status: ComplaintStatus) => {
    const updated = updateComplaintStatus(id, status);
    if (updated) {
      setComplaints((prev) => prev.map((c) => (c.id === id ? updated : c)));
      toast({ title: 'Status Updated', description: `Complaint moved to ${statusLabels[status]}.` });
    }
  };

  const handleResolve = (id: string, photo: string, remarks?: string) => {
    const updated = resolveComplaint(id, photo, remarks);
    if (updated) {
      setComplaints((prev) => prev.map((c) => (c.id === id ? updated : c)));
      toast({ title: 'Issue Resolved', description: 'The complaint has been marked as resolved with proof.' });
    }
  };

  const handleLogout = () => {
    logout();
    toast({ title: 'Logged out', description: 'See you next time!' });
    navigate('/');
  };

  if (!user || user.role !== 'admin') return null;

  return (
    <div className="min-h-screen gradient-bg noise-overlay relative">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-primary/20 blur-3xl" animate={{ scale: [1, 1.2, 1] }} transition={{ duration: 20, repeat: Infinity }} />
        <motion.div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-accent/20 blur-3xl" animate={{ scale: [1.2, 1, 1.2] }} transition={{ duration: 25, repeat: Infinity }} />
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8 max-w-7xl">
        <motion.header initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold font-display gradient-text mb-2">Admin Dashboard</h1>
            <p className="text-muted-foreground flex items-center gap-2">
              <UserCog className="w-4 h-4" />
              {user.name}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <ThemeToggle />
            <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={handleLogout} className="p-3 rounded-xl glass-card text-destructive" data-testid="button-logout">
              <LogOut className="w-5 h-5" />
            </motion.button>
          </div>
        </motion.header>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          <StatCard title="Total Issues" value={stats.total} icon={<TrendingUp className="w-6 h-6" />} gradient="stat-gradient-total" delay={0} />
          <StatCard title="Pending" value={stats.pending} icon={<AlertCircle className="w-6 h-6" />} gradient="stat-gradient-pending" delay={0.1} />
          <StatCard title="In Progress" value={stats.inProgress} icon={<Clock className="w-6 h-6" />} gradient="stat-gradient-progress" delay={0.2} />
          <StatCard title="Resolved" value={stats.resolved} icon={<CheckCircle2 className="w-6 h-6" />} gradient="stat-gradient-resolved" delay={0.3} />
        </div>

        <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10">
          <div className="glass-card rounded-2xl p-6">
            <h2 className="text-xl font-semibold font-display mb-4 flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-primary" />
              Status Distribution
            </h2>
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={5} dataKey="value">
                    {pieData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={CHART_COLORS[index]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: 'none', borderRadius: '12px' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center gap-6">
              {pieData.map((entry, index) => (
                <div key={entry.name} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: CHART_COLORS[index] }} />
                  <span className="text-sm text-muted-foreground">{entry.name}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card rounded-2xl p-6">
            <h2 className="text-xl font-semibold font-display mb-4 flex items-center gap-2">
              <Filter className="w-5 h-5 text-accent" />
              By Category
            </h2>
            <div className="h-52">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData} layout="vertical">
                  <XAxis type="number" hide />
                  <YAxis type="category" dataKey="category" width={90} tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: 'none', borderRadius: '12px' }} />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </motion.section>

        <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
            <h2 className="text-2xl font-bold font-display">All Complaints</h2>

            <div className="flex flex-wrap items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input placeholder="Search..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10 w-52" data-testid="input-search" />
              </div>

              <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as ComplaintStatus | 'all')}>
                <SelectTrigger className="w-36" data-testid="select-status-filter">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                </SelectContent>
              </Select>

              <Select value={categoryFilter} onValueChange={(v) => setCategoryFilter(v as ComplaintCategory | 'all')}>
                <SelectTrigger className="w-40" data-testid="select-category-filter">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {Object.entries(categoryLabels).map(([key, label]) => (
                    <SelectItem key={key} value={key}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <AnimatePresence mode="popLayout">
            {filteredComplaints.length === 0 ? (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card rounded-2xl p-12 text-center">
                <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No complaints found</h3>
                <p className="text-muted-foreground">Try adjusting your filters.</p>
              </motion.div>
            ) : (
              <div className="grid gap-3">
                {filteredComplaints.map((complaint) => (
                  <ComplaintRow key={complaint.id} complaint={complaint} onClick={() => setSelectedComplaint(complaint)} />
                ))}
              </div>
            )}
          </AnimatePresence>
        </motion.section>

        <motion.footer initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="mt-16 text-center text-muted-foreground text-sm">
          <p>CivicPulse Admin — Managing community issues</p>
        </motion.footer>
      </div>

      {selectedComplaint && (
        <ComplaintDetailModal
          complaint={selectedComplaint}
          isOpen={!!selectedComplaint}
          onClose={() => setSelectedComplaint(null)}
          onStatusUpdate={handleStatusUpdate}
          onResolve={handleResolve}
        />
      )}
    </div>
  );
}